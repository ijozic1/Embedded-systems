#include "mbed.h"

#include "stdio.h"
#include "LCD/SPI_TFT_ILI9341.h"
#include "string"
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"
//#include "SDFileSystem.h"

SPI_TFT_ILI9341 TFT(PTD2,PTD3,PTD1,PTD0,PTD5,PTA13,"TFT");
                 // mosi,miso,sclk,cs  ,reset,dc

int main() {
    int i=0;
    //Inicijalizacija;
    TFT.claim(stdout);
    TFT.set_orientation(1);
    TFT.background(Blue);
    TFT.cls();
    while(1) {
        //Ispis teksta
        TFT.set_font((unsigned char*) Arial28x28);
        TFT.locate(20,20);
        TFT.foreground(Magenta);
        TFT._putc('X');
        TFT.foreground(White);
        TFT.locate(20,50);
        TFT._printf("Mi volimo US!",13);
        TFT.set_font((unsigned char*) Arial24x23);
        TFT.foreground(Cyan);
        TFT.locate(30,120);
        TFT._printf("Mi volimo US!",13);
        TFT.set_font((unsigned char*) Arial12x12);
        TFT.foreground(Cyan);
        TFT.locate(50,190);
        TFT._printf("Mi volimo US!",13);
        wait_us(2e6);
        //Crtanje linija
        TFT.line(0,0,100,0,Green);
        TFT.line(0,0,0,200,Green);
        TFT.line(0,0,100,200,Green);
        //Crtanje dijagrama piksel po poksel
        double s;
        for (i=0; i<320; i++) {
            s =20 * sin((long double) i / 10 );
            TFT.pixel(i,100 + (int)s ,Red);
        }
        TFT.fillrect(100,100,150,150,Yellow);
        TFT.fillcircle(200,170,40,Cyan);
        wait_us(2e6);
        TFT.cls();
    }
}
