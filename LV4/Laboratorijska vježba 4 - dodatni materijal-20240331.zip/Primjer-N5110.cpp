#include "mbed.h"
#include "N5110.h"
#include "lpc1114etf.h"

//N5110 lcd(VCC,SCE, RST, DC, MOSI,SCLK,LED));
N5110   lcd(dp4,dp24,dp23,dp25,dp2,dp6,dp18);
DigitalOut enable(LED_ACT);

int main() {
    //deaktivacija led dioda
    enable=1;
    //inicijalizacija displeja
    lcd.init();
    //prikaz stringa
    lcd.printString("Mi volimo US!",0,0);
    while(1);
}